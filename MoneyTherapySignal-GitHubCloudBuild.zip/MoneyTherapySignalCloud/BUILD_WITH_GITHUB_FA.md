# ساخت APK فقط با گوشی و GitHub

این پروژه AndroidIDE نمی‌خواهد. GitHub Actions فایل APK را روی سرورهای GitHub می‌سازد.

1. در github.com یک Repository جدید بسازید.
2. فایل‌های این پروژه را داخل Repository قرار دهید، به‌خصوص پوشه `.github/workflows`.
3. به تب Actions بروید.
4. Workflow با نام `Build MoneyTherapy APK` را باز کنید.
5. اگر خودکار اجرا نشده بود، `Run workflow` را بزنید.
6. بعد از سبز شدن Build، پایین صفحه بخش Artifacts را باز کنید.
7. `MoneyTherapySignal-APK` را دانلود کنید. داخل فایل دانلودی، `app-debug.apk` قرار دارد.

نکته: APK از نوع debug و برای نصب مستقیم روی گوشی مناسب است.
