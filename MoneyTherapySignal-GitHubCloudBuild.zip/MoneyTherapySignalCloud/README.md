# MoneyTherapy Signal — Phone Build Edition

اپ اندرویدی آفلاین برای Parse کردن قالب سیگنال MoneyTherapy و اعمال همان فرمول‌ها و روش مدیریت معامله‌ای که در گفتگو ارائه شده است.

برای ساخت APK فقط با گوشی، فایل `BUILD_ON_PHONE_FA.md` را بخوانید.

## مشخصات Build
- Java
- Min SDK 23
- Compile/Target SDK 33
- Build Tools 33.0.3
- Android Gradle Plugin 7.4.2
- Gradle 7.6.4
- بدون dependency جانبی برای کد اپ
