#!/system/bin/sh
set -e
cd "$(dirname "$0")"
AAPT2="$HOME/.androidide/aapt2"
if [ -f "$AAPT2" ]; then
  exec ./gradlew -Pandroid.aapt2FromMavenOverride="$AAPT2" assembleDebug
else
  exec ./gradlew assembleDebug
fi
