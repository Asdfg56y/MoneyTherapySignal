package com.moneytherapy.signalcalc;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SignalParser {
    private SignalParser() {}

    public static Signal parse(String raw) {
        String s = normalizeDigits(raw == null ? "" : raw);
        Signal out = new Signal();

        out.name = matchText(s, "(?im)^\\s*(?:🪙\\s*)?Name\\s*:\\s*([A-Z0-9_\\-/]+)");
        out.position = matchText(s, "(?im)^\\s*(?:📊\\s*)?Position\\s*:\\s*(BUY|SELL|LONG|SHORT)").toUpperCase(Locale.US);
        if (out.position.equals("LONG")) out.position = "BUY";
        if (out.position.equals("SHORT")) out.position = "SELL";
        out.timeframe = matchText(s, "(?im)^\\s*(?:⏱\\s*)?TF\\s*:\\s*([^\\r\\n]+)").trim();

        out.entry = matchNumber(s, "(?im)^\\s*(?:🟢\\s*)?Entry(?:\\s+Market)?\\s*:\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)");

        for (int i = 1; i <= 5; i++) {
            double tp = matchNumber(s, "(?im)^\\s*(?:📌\\s*)?TP" + i + "\\s*:\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)");
            if (!Double.isNaN(tp)) out.targets.add(tp);
        }

        out.stopLoss = matchNumber(s,
                "(?im)^\\s*(?:🛑\\s*)?(?:حد\\s*ضرر|حدضرر|Stop\\s*Loss|SL)\\s*:\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)");
        out.stopPercent = matchNumber(s,
                "(?im)^\\s*(?:🛑\\s*)?(?:حد\\s*ضرر|حدضرر|Stop\\s*Loss|SL)[^\\r\\n]*?\\(([0-9]+(?:\\.[0-9]+)?)\\s*%\\)");
        return out;
    }

    private static String matchText(String s, String regex) {
        Matcher m = Pattern.compile(regex).matcher(s);
        return m.find() ? m.group(1).trim() : "";
    }

    private static double matchNumber(String s, String regex) {
        Matcher m = Pattern.compile(regex).matcher(s);
        if (!m.find()) return Double.NaN;
        try {
            return Double.parseDouble(m.group(1).replace(",", ""));
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    public static String normalizeDigits(String input) {
        if (input == null) return "";
        char[] fa = {'۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'};
        char[] ar = {'٠','١','٢','٣','٤','٥','٦','٧','٨','٩'};
        String out = input;
        for (int i = 0; i < 10; i++) {
            out = out.replace(fa[i], (char)('0' + i));
            out = out.replace(ar[i], (char)('0' + i));
        }
        out = out.replace('٫', '.').replace('٬', ',');
        return out;
    }
}
