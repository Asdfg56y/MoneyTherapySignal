package com.moneytherapy.signalcalc;

public final class TradeMath {
    private TradeMath() {}

    public static double riskDollars(double capital, double riskPercent) {
        if (capital <= 0 || riskPercent <= 0) return Double.NaN;
        return capital * riskPercent / 100.0;
    }

    public static double slDistancePercent(Signal s) {
        if (s == null || Double.isNaN(s.entry) || s.entry <= 0 || Double.isNaN(s.stopLoss) || s.stopLoss <= 0) return Double.NaN;
        // همان فرمول توضیح‌داده‌شده: فاصله واقعی Entry تا SL تقسیم بر Entry.
        // قدرمطلق باعث می‌شود برای BUY و SELL یک فرمول واحد داشته باشیم.
        return Math.abs(s.entry - s.stopLoss) / s.entry * 100.0;
    }

    public static double positionSize(double riskDollars, double slDistancePercent) {
        if (Double.isNaN(riskDollars) || riskDollars <= 0 || Double.isNaN(slDistancePercent) || slDistancePercent <= 0) return Double.NaN;
        return riskDollars / (slDistancePercent / 100.0);
    }

    public static double leverage(double positionSize, double margin) {
        if (margin <= 0) return Double.NaN;
        return positionSize / margin;
    }

    public static double margin(double positionSize, double leverage) {
        if (leverage <= 0) return Double.NaN;
        return positionSize / leverage;
    }

    public static double profitAtTarget(Signal s, double target, double positionSize) {
        if (s == null || Double.isNaN(s.entry) || s.entry <= 0 || Double.isNaN(target) || Double.isNaN(positionSize) || positionSize <= 0) {
            return Double.NaN;
        }
        double move;
        if ("BUY".equals(s.position)) {
            move = (target - s.entry) / s.entry;
        } else {
            move = (s.entry - target) / s.entry;
        }
        return positionSize * move;
    }
}
