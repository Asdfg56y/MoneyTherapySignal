package com.moneytherapy.signalcalc;

public final class TradeMath {
    private TradeMath() {}

    public static double riskDollars(double capital, double riskPercent) {
        if (capital <= 0 || riskPercent <= 0) return Double.NaN;
        return capital * riskPercent / 100.0;
    }

    public static double slDistancePercent(Signal s) {
        if (s == null || Double.isNaN(s.entry) || s.entry <= 0 || Double.isNaN(s.stopLoss) || s.stopLoss <= 0) return Double.NaN;
        // همان فرمول توضیح‌داده‌شده: فاصله واقعی Entry تا SL تقسیم بر Entry.
        // قدرمطلق باعث می‌شود برای BUY و SELL یک فرمول واحد داشته باشیم.
        return Math.abs(s.entry - s.stopLoss) / s.entry * 100.0;
    }

    public static double positionSize(double riskDollars, double slDistancePercent) {
        if (Double.isNaN(riskDollars) || riskDollars <= 0 || Double.isNaN(slDistancePercent) || slDistancePercent <= 0) return Double.NaN;
        return riskDollars / (slDistancePercent / 100.0);
    }

    public static double leverage(double positionSize, double margin) {
        if (margin <= 0) return Double.NaN;
        return positionSize / margin;
    }

    public static double margin(double positionSize, double leverage) {
        if (leverage <= 0) return Double.NaN;
        return positionSize / leverage;
    }

    public static double profitAtTarget(Signal s, double target, double positionSize) {
        if (s == null || Double.isNaN(s.entry) || s.entry <= 0 || Double.isNaN(target) || Double.isNaN(positionSize) || positionSize <= 0) {
            return Double.NaN;
        }
        double move;
        if ("BUY".equals(s.position)) {
            move = (target - s.entry) / s.entry;
        } else {
            move = (s.entry - target) / s.entry;
        }
        return positionSize * move;
    }
    public static double positionFromMarginLeverage(double margin, double leverage) {
        if (margin <= 0 || leverage <= 0) return Double.NaN;
        return margin * leverage;
    }

    public static double baseQuantity(Signal s, double positionSize) {
        if (s == null || Double.isNaN(s.entry) || s.entry <= 0 || Double.isNaN(positionSize) || positionSize <= 0) return Double.NaN;
        return positionSize / s.entry;
    }

    public static double notionalAtPrice(Signal s, double exitPrice, double positionSize) {
        double qty = baseQuantity(s, positionSize);
        if (Double.isNaN(qty) || Double.isNaN(exitPrice) || exitPrice <= 0) return Double.NaN;
        return qty * exitPrice;
    }

    public static double fee(double notional, double feePercent) {
        if (Double.isNaN(notional) || notional < 0 || Double.isNaN(feePercent) || feePercent < 0) return Double.NaN;
        return notional * feePercent / 100.0;
    }

    public static double netPnlAtExit(Signal s, double exitPrice, double positionSize,
                                      double entryFeePercent, double exitFeePercent, double extraCosts) {
        if (s == null || exitPrice <= 0 || positionSize <= 0 || entryFeePercent < 0 || exitFeePercent < 0 || extraCosts < 0) {
            return Double.NaN;
        }
        double gross = profitAtTarget(s, exitPrice, positionSize);
        double entryFee = fee(positionSize, entryFeePercent);
        double exitNotional = notionalAtPrice(s, exitPrice, positionSize);
        double exitFee = fee(exitNotional, exitFeePercent);
        if (Double.isNaN(gross) || Double.isNaN(entryFee) || Double.isNaN(exitFee)) return Double.NaN;
        return gross - entryFee - exitFee - extraCosts;
    }

}
