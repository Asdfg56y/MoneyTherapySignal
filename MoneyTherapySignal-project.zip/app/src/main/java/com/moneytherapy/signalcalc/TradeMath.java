package com.moneytherapy.signalcalc;

public final class TradeMath {
    private TradeMath() {}

    public static double riskDollars(double capital, double riskPercent) {
        return capital * riskPercent / 100.0;
    }

    public static double slDistancePercent(Signal s) {
        if (!Double.isNaN(s.stopPercent) && s.stopPercent > 0) return s.stopPercent;
        if (Double.isNaN(s.entry) || s.entry == 0 || Double.isNaN(s.stopLoss)) return Double.NaN;
        return Math.abs(s.entry - s.stopLoss) / s.entry * 100.0;
    }

    public static double positionSize(double riskDollars, double slDistancePercent) {
        if (slDistancePercent <= 0) return Double.NaN;
        return riskDollars / (slDistancePercent / 100.0);
    }

    public static double leverage(double positionSize, double margin) {
        if (margin <= 0) return Double.NaN;
        return positionSize / margin;
    }
}
