package com.moneytherapy.signalcalc;

import java.util.ArrayList;
import java.util.List;

public class Signal {
    public String name = "";
    public String position = "";
    public String timeframe = "";
    public double entry = Double.NaN;
    public double stopLoss = Double.NaN;
    public double stopPercent = Double.NaN;
    public final List<Double> targets = new ArrayList<>();

    public boolean isValid() {
        return !name.isEmpty() && !position.isEmpty() && !Double.isNaN(entry)
                && !Double.isNaN(stopLoss) && targets.size() >= 5;
    }
}
