package com.moneytherapy.signalcalc;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 13, 22);
    private final int SURFACE = Color.rgb(18, 24, 39);
    private final int SURFACE2 = Color.rgb(23, 31, 49);
    private final int TEXT = Color.rgb(245, 247, 251);
    private final int MUTED = Color.rgb(174, 183, 199);
    private final int ACCENT = Color.rgb(33, 212, 167);
    private final int BLUE = Color.rgb(55, 168, 255);
    private final int DANGER = Color.rgb(255, 91, 112);
    private final int GOLD = Color.rgb(247, 199, 94);
    private final int LINE = Color.rgb(38, 49, 73);

    private EditText signalInput, capitalInput, riskInput, marginInput;
    private LinearLayout outputArea;
    private final DecimalFormat money = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat price = new DecimalFormat("#,##0.########", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat pct = new DecimalFormat("0.####", DecimalFormatSymbols.getInstance(Locale.US));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(36));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("MoneyTherapy Signal", 27, TEXT, true);
        title.setGravity(Gravity.START);
        root.addView(title);

        TextView sub = text("محاسبه بر اساس فرمول‌ها و روش مدیریت معامله استاد", 14, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub);

        LinearLayout signalCard = card();
        signalCard.addView(sectionTitle("متن سیگنال"));
        signalInput = edit("سیگنال استاد را اینجا Paste کنید", false, 8);
        signalInput.setGravity(Gravity.TOP | Gravity.START);
        signalCard.addView(signalInput, new LinearLayout.LayoutParams(-1, dp(205)));
        root.addView(signalCard);

        LinearLayout riskCard = card();
        riskCard.addView(sectionTitle("سرمایه و ریسک"));
        capitalInput = edit("سرمایه (USDT)", true, 1);
        riskInput = edit("درصد ریسک هر معامله", true, 1);
        marginInput = edit("مارجین موردنظر (USDT)", true, 1);
        riskCard.addView(capitalInput);
        riskCard.addView(space(8));
        riskCard.addView(riskInput);
        riskCard.addView(space(8));
        riskCard.addView(marginInput);
        TextView hint = text("طبق توضیح استاد: ابتدا درصد ریسک را خودتان انتخاب کنید؛ برای شروع ۵ تا ۱۰ درصد را مثال زده است.", 12, MUTED, false);
        hint.setPadding(0, dp(10), 0, 0);
        riskCard.addView(hint);
        root.addView(riskCard);

        Button calc = new Button(this);
        calc.setText("اعمال روی سیگنال");
        calc.setTextSize(16);
        calc.setTextColor(Color.rgb(4, 20, 18));
        calc.setTypeface(Typeface.DEFAULT_BOLD);
        calc.setAllCaps(false);
        calc.setBackground(round(ACCENT, 16, ACCENT));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.setMargins(0, dp(4), 0, dp(16));
        root.addView(calc, bp);

        outputArea = new LinearLayout(this);
        outputArea.setOrientation(LinearLayout.VERTICAL);
        root.addView(outputArea);

        calc.setOnClickListener(v -> calculate());
        setContentView(scroll);
    }

    private void calculate() {
        String raw = signalInput.getText().toString().trim();
        double capital = number(capitalInput.getText().toString());
        double riskPct = number(riskInput.getText().toString());
        double margin = number(marginInput.getText().toString());

        if (raw.isEmpty() || Double.isNaN(capital) || Double.isNaN(riskPct) || Double.isNaN(margin)) {
            Toast.makeText(this, "متن سیگنال، سرمایه، درصد ریسک و مارجین را وارد کنید.", Toast.LENGTH_SHORT).show();
            return;
        }

        Signal s = SignalParser.parse(raw);
        if (!s.isValid()) {
            Toast.makeText(this, "قالب سیگنال کامل تشخیص داده نشد. Name، Position، Entry، TP1 تا TP5 و حدضرر را بررسی کنید.", Toast.LENGTH_LONG).show();
            return;
        }

        double riskDollar = TradeMath.riskDollars(capital, riskPct);
        double slPct = TradeMath.slDistancePercent(s);
        double position = TradeMath.positionSize(riskDollar, slPct);
        double leverage = TradeMath.leverage(position, margin);

        outputArea.removeAllViews();
        outputArea.addView(signalSummaryCard(s));
        outputArea.addView(resultCard(riskDollar, slPct, position, leverage));
        outputArea.addView(planCard(s, position));
    }

    private LinearLayout signalSummaryCard(Signal s) {
        LinearLayout c = card();
        c.addView(sectionTitle("خلاصه سیگنال"));
        int posColor = s.position.equals("BUY") ? ACCENT : DANGER;
        c.addView(kv("نماد", s.name, TEXT));
        c.addView(kv("پوزیشن", s.position, posColor));
        c.addView(kv("تایم‌فریم", s.timeframe, TEXT));
        c.addView(kv("ورود", price.format(s.entry), TEXT));
        for (int i = 0; i < s.targets.size(); i++) {
            c.addView(kv("TP" + (i + 1), price.format(s.targets.get(i)), GOLD));
        }
        c.addView(kv("SL", price.format(s.stopLoss), DANGER));
        return c;
    }

    private LinearLayout resultCard(double riskDollar, double slPct, double position, double leverage) {
        LinearLayout c = card();
        c.addView(sectionTitle("محاسبات فرمول استاد"));
        c.addView(formula("ریسک دلاری", money.format(riskDollar) + " USDT"));
        c.addView(formula("فاصله ورود تا حدضرر", pct.format(slPct) + "%"));
        c.addView(formula("حجم پوزیشن", money.format(position) + " USDT"));
        c.addView(formula("اهرم", pct.format(leverage) + "x"));
        return c;
    }

    private LinearLayout planCard(Signal s, double position) {
        LinearLayout c = card();
        c.addView(sectionTitle("مدیریت معامله طبق توضیح استاد"));

        String direction = s.position.equals("BUY") ? "پایین‌تر" : "بالاتر";
        c.addView(step("SL", DANGER,
                "SL خودکار را حذف یا غیرفعال کنید و عدد " + price.format(s.stopLoss) + " را یادداشت کنید. " +
                        "اگر یک کندل ۵ دقیقه‌ای کامل " + direction + " از SL بسته شد، معامله را دستی ببندید. " +
                        "اگر فقط سایه کندل به SL رسید و کندل داخل محدوده بسته شد، معامله باز بماند."));

        double half = position * 0.5;
        c.addView(step("TP1  •  " + price.format(s.targets.get(0)), ACCENT,
                "نیمی از پوزیشن را ببندید (۵۰٪ = " + money.format(half) + " USDT از حجم پوزیشن) و SL باقی‌مانده را به نقطه ورود " + price.format(s.entry) + " بیاورید."));

        c.addView(step("TP2  •  " + price.format(s.targets.get(1)), BLUE,
                "دوباره بخشی از پوزیشن را ببندید و SL را به TP1 یعنی " + price.format(s.targets.get(0)) + " بیاورید."));
        c.addView(step("TP3  •  " + price.format(s.targets.get(2)), BLUE,
                "بخشی از پوزیشن را ببندید و SL را به TP2 یعنی " + price.format(s.targets.get(1)) + " بیاورید."));
        c.addView(step("TP4  •  " + price.format(s.targets.get(3)), BLUE,
                "بخشی از پوزیشن را ببندید و SL را به TP3 یعنی " + price.format(s.targets.get(2)) + " بیاورید."));
        c.addView(step("TP5  •  " + price.format(s.targets.get(4)), GOLD,
                "باقی‌مانده کوچک پوزیشن را تا TP5 نگه دارید تا بسته شود."));
        return c;
    }

    private TextView step(String heading, int color, String body) {
        TextView v = text(heading + "\n" + body, 14, TEXT, false);
        v.setLineSpacing(0, 1.25f);
        v.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable bg = round(SURFACE2, 14, color);
        bg.setStroke(dp(1), color);
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(7));
        v.setLayoutParams(lp);
        return v;
    }

    private TextView formula(String label, String value) {
        return kv(label, value, ACCENT);
    }

    private TextView kv(String label, String value, int valueColor) {
        TextView t = text(label + "    " + value, 15, TEXT, false);
        t.setPadding(dp(2), dp(8), dp(2), dp(8));
        if (valueColor != TEXT) {
            android.text.SpannableString sp = new android.text.SpannableString(t.getText());
            int start = label.length() + 4;
            sp.setSpan(new android.text.style.ForegroundColorSpan(valueColor), start, sp.length(), 0);
            sp.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), start, sp.length(), 0);
            t.setText(sp);
        }
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(round(SURFACE, 18, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(14));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(0, 0, 0, dp(12));
        return t;
    }

    private EditText edit(String hint, boolean numeric, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(round(SURFACE2, 13, LINE));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setMinLines(minLines);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != fill) g.setStroke(dp(1), stroke);
        return g;
    }

    private double number(String s) {
        try {
            String n = SignalParser.normalizeDigits(s).replace(",", "").trim();
            if (n.isEmpty()) return Double.NaN;
            return Double.parseDouble(n);
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
