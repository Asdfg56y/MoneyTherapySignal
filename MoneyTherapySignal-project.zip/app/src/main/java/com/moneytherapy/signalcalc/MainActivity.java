package com.moneytherapy.signalcalc;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 13, 22);
    private final int SURFACE = Color.rgb(18, 24, 39);
    private final int SURFACE2 = Color.rgb(23, 31, 49);
    private final int TEXT = Color.rgb(245, 247, 251);
    private final int MUTED = Color.rgb(174, 183, 199);
    private final int ACCENT = Color.rgb(33, 212, 167);
    private final int BLUE = Color.rgb(55, 168, 255);
    private final int DANGER = Color.rgb(255, 91, 112);
    private final int GOLD = Color.rgb(247, 199, 94);
    private final int LINE = Color.rgb(38, 49, 73);

    private EditText signalInput, capitalInput, riskInput, marginInput, leverageInput;
    private LinearLayout outputArea;
    private final DecimalFormat money = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat price = new DecimalFormat("#,##0.########", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat pct = new DecimalFormat("0.####", DecimalFormatSymbols.getInstance(Locale.US));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(36));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("MoneyTherapy Signal", 27, TEXT, true);
        title.setGravity(Gravity.START);
        root.addView(title);

        TextView sub = text("محاسبه بر اساس فرمول‌ها و روش مدیریت معامله استاد", 14, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub);

        LinearLayout signalCard = card();
        signalCard.addView(sectionTitle("متن سیگنال"));
        signalInput = edit("سیگنال استاد را اینجا Paste کنید", false, 8);
        signalInput.setGravity(Gravity.TOP | Gravity.START);
        signalCard.addView(signalInput, new LinearLayout.LayoutParams(-1, dp(205)));
        root.addView(signalCard);

        LinearLayout riskCard = card();
        riskCard.addView(sectionTitle("سرمایه و ریسک"));
        capitalInput = edit("سرمایه (USDT)", true, 1);
        riskInput = edit("درصد ریسک هر معامله", true, 1);
        marginInput = edit("مارجین موردنظر (USDT) — اختیاری", true, 1);
        leverageInput = edit("اهرم موردنظر (x) — اختیاری", true, 1);
        riskCard.addView(capitalInput);
        riskCard.addView(space(8));
        riskCard.addView(riskInput);
        riskCard.addView(space(8));
        riskCard.addView(marginInput);
        riskCard.addView(space(8));
        riskCard.addView(leverageInput);
        TextView hint = text("طبق توضیح استاد: ابتدا درصد ریسک را خودتان انتخاب کنید. فاصله Entry تا SL مبنای محاسبه حجم پوزیشن است. اگر مارجین را وارد کنید اهرم لازم محاسبه می‌شود؛ اگر اهرم را وارد کنید مارجین لازم محاسبه می‌شود. استاد برای شروع معمولاً ۵ تا ۱۰٪ را مناسب‌تر و امن‌تر ذکر کرده بود.", 12, MUTED, false);
        hint.setPadding(0, dp(10), 0, 0);
        riskCard.addView(hint);
        root.addView(riskCard);

        Button calc = new Button(this);
        calc.setText("اعمال روی سیگنال");
        calc.setTextSize(16);
        calc.setTextColor(Color.rgb(4, 20, 18));
        calc.setTypeface(Typeface.DEFAULT_BOLD);
        calc.setAllCaps(false);
        calc.setBackground(round(ACCENT, 16, ACCENT));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.setMargins(0, dp(4), 0, dp(16));
        root.addView(calc, bp);

        outputArea = new LinearLayout(this);
        outputArea.setOrientation(LinearLayout.VERTICAL);
        root.addView(outputArea);

        calc.setOnClickListener(v -> calculate());
        setContentView(scroll);
    }

    private void calculate() {
        String raw = signalInput.getText().toString().trim();
        double capital = number(capitalInput.getText().toString());
        double riskPct = number(riskInput.getText().toString());
        double margin = number(marginInput.getText().toString());
        double requestedLeverage = number(leverageInput.getText().toString());

        if (raw.isEmpty() || Double.isNaN(capital) || Double.isNaN(riskPct)) {
            Toast.makeText(this, "متن سیگنال، سرمایه و درصد ریسک را وارد کنید.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (capital <= 0 || riskPct <= 0) {
            Toast.makeText(this, "سرمایه و درصد ریسک باید بزرگ‌تر از صفر باشند.", Toast.LENGTH_SHORT).show();
            return;
        }
        Signal s = SignalParser.parse(raw);
        if (!s.isValid()) {
            Toast.makeText(this, "قالب سیگنال کامل تشخیص داده نشد. Name، Position، Entry، TP1 تا TP5 و حدضرر را بررسی کنید.", Toast.LENGTH_LONG).show();
            return;
        }

        String signalError = validateSignalLevels(s);
        if (signalError != null) {
            Toast.makeText(this, signalError, Toast.LENGTH_LONG).show();
            return;
        }

        double riskDollar = TradeMath.riskDollars(capital, riskPct);
        double slPct = TradeMath.slDistancePercent(s);
        double position = TradeMath.positionSize(riskDollar, slPct);

        double leverageFromMargin = (!Double.isNaN(margin) && margin > 0)
                ? TradeMath.leverage(position, margin) : Double.NaN;
        double marginFromLeverage = (!Double.isNaN(requestedLeverage) && requestedLeverage > 0)
                ? TradeMath.margin(position, requestedLeverage) : Double.NaN;

        outputArea.removeAllViews();
        outputArea.addView(signalSummaryCard(s));
        outputArea.addView(resultCard(s, riskDollar, slPct, position, margin, requestedLeverage, leverageFromMargin, marginFromLeverage));
        outputArea.addView(profitCard(s, position));
        outputArea.addView(planCard(s, position));
    }

    private LinearLayout signalSummaryCard(Signal s) {
        LinearLayout c = card();
        c.addView(sectionTitle("خلاصه سیگنال"));
        int posColor = s.position.equals("BUY") ? ACCENT : DANGER;
        c.addView(kv("نماد", s.name, TEXT));
        c.addView(kv("پوزیشن", s.position, posColor));
        c.addView(kv("تایم‌فریم", s.timeframe, TEXT));
        c.addView(kv("ورود", price.format(s.entry), TEXT));
        for (int i = 0; i < s.targets.size(); i++) {
            c.addView(kv("TP" + (i + 1), price.format(s.targets.get(i)), GOLD));
        }
        c.addView(kv("SL", price.format(s.stopLoss), DANGER));
        return c;
    }

    private LinearLayout resultCard(Signal s, double riskDollar, double slPct, double position,
                                    double enteredMargin, double enteredLeverage,
                                    double leverageFromMargin, double marginFromLeverage) {
        LinearLayout c = card();
        c.addView(sectionTitle("محاسبات فرمول استاد"));
        c.addView(formula("ریسک محاسباتی تا عدد SL", money.format(riskDollar) + " USDT"));
        c.addView(formula("فاصله Entry تا SL", pct.format(slPct) + "%"));
        if (!Double.isNaN(s.stopPercent) && s.stopPercent > 0) {
            c.addView(kv("درصد نوشته‌شده در سیگنال", pct.format(s.stopPercent) + "%", MUTED));
        }
        c.addView(formula("حجم پوزیشن", money.format(position) + " USDT"));

        if (!Double.isNaN(enteredMargin) && enteredMargin > 0) {
            c.addView(kv("مارجین واردشده", money.format(enteredMargin) + " USDT", TEXT));
            c.addView(formula("اهرم لازم با این مارجین", pct.format(leverageFromMargin) + "x"));
        }
        if (!Double.isNaN(enteredLeverage) && enteredLeverage > 0) {
            c.addView(kv("اهرم واردشده", pct.format(enteredLeverage) + "x", TEXT));
            c.addView(formula("مارجین لازم با این اهرم", money.format(marginFromLeverage) + " USDT"));
        }

        if ((Double.isNaN(enteredMargin) || enteredMargin <= 0)
                && (Double.isNaN(enteredLeverage) || enteredLeverage <= 0)) {
            c.addView(step("مارجین / اهرم", BLUE,
                    "حجم پوزیشن محاسبه شد. برای محاسبه اهرم، مارجین را وارد کنید؛ یا برای محاسبه مارجین، اهرم را وارد کنید."));
        }

        c.addView(step("نکته اجرای حدضرر", DANGER,
                "عدد SL در این محاسبات برای تعیین فاصله و حجم پوزیشن استفاده شده است. طبق روش استاد، برخورد لحظه‌ای یا سایه به SL به‌تنهایی خروج نیست؛ خروج دستی زمانی انجام می‌شود که کندل ۵ دقیقه‌ای آن طرف سطح SL بسته شود. بنابراین عدد ریسک بالا «ریسک محاسباتی تا سطح SL» است و لزوماً با مبلغ نهایی خروج دستی یکی نیست."));

        if (!Double.isNaN(enteredMargin) && enteredMargin > 0
                && !Double.isNaN(enteredLeverage) && enteredLeverage > 0) {
            double expectedPosition = enteredMargin * enteredLeverage;
            double diff = Math.abs(expectedPosition - position);
            double tolerance = Math.max(0.01, position * 0.005);
            if (diff > tolerance) {
                c.addView(step("تطبیق مارجین و اهرم", GOLD,
                        "این دو ورودی با حجم پوزیشن محاسبه‌شده یکسان نیستند. " +
                                "با مارجین " + money.format(enteredMargin) + "، اهرم لازم " + pct.format(leverageFromMargin) + "x است؛ " +
                                "یا با اهرم " + pct.format(enteredLeverage) + "x، مارجین لازم " + money.format(marginFromLeverage) + " USDT است."));
            }
        }
        return c;
    }


    private LinearLayout profitCard(Signal s, double position) {
        LinearLayout c = card();
        c.addView(sectionTitle("سود دلاری در هر تارگت"));
        TextView profitHint = text("اعداد «سود کل حجم» نشان می‌دهند اگر کل حجم محاسبه‌شده تا آن TP باز باشد، سود آن قیمت چقدر است. در اجرای مرحله‌ای استاد فقط مقدار خروج TP1 دقیقاً ۵۰٪ مشخص شده است.", 12, MUTED, false);
        profitHint.setPadding(0, 0, 0, dp(8));
        c.addView(profitHint);

        for (int i = 0; i < s.targets.size(); i++) {
            double tp = s.targets.get(i);
            double fullProfit = TradeMath.profitAtTarget(s, tp, position);
            String label = "TP" + (i + 1) + "  •  " + price.format(tp);
            String body = "سود کل حجم پوزیشن در این قیمت: " + money.format(fullProfit) + " USDT";

            if (i == 0) {
                double realizedTp1 = fullProfit * 0.5;
                body += "\nطبق توضیح استاد با بستن ۵۰٪ پوزیشن در TP1، سودی که در این مرحله گرفته می‌شود: "
                        + money.format(realizedTp1) + " USDT";
            } else if (i < 4) {
                body += "\nبرای مقدار سودی که در این مرحله واقعاً برداشت می‌شود، درصد بخشی که باید بسته شود در توضیح استاد مشخص نشده است.";
            } else {
                body += "\nسود نهایی دقیقِ روش مرحله‌ای به مقدار پوزیشنی بستگی دارد که پس از TP2 تا TP4 باقی مانده است؛ آن درصدها در توضیح استاد مشخص نشده‌اند.";
            }

            c.addView(step(label, i == 0 ? ACCENT : (i == 4 ? GOLD : BLUE), body));
        }
        return c;
    }

    private LinearLayout planCard(Signal s, double position) {
        LinearLayout c = card();
        c.addView(sectionTitle("مدیریت معامله طبق توضیح استاد"));

        String direction = s.position.equals("BUY") ? "پایین‌تر" : "بالاتر";
        c.addView(step("SL اولیه  •  " + price.format(s.stopLoss), DANGER,
                "عدد SL برای محاسبه ریسک و حجم پوزیشن در نظر گرفته می‌شود، اما SL خودکار باید حذف یا غیرفعال باشد. " +
                        "اگر قیمت فقط به این سطح برسد یا سایه کندل از آن عبور کند، معامله بسته نمی‌شود. " +
                        "فقط اگر یک کندل ۵ دقیقه‌ای کامل " + direction + " از سطح SL بسته شد، معامله را دستی ببندید."));

        double half = position * 0.5;
        c.addView(step("TP1  •  " + price.format(s.targets.get(0)), ACCENT,
                "نیمی از پوزیشن را ببندید (۵۰٪ = " + money.format(half) + " USDT از حجم پوزیشن) و سطح مرجع SL باقی‌مانده را به نقطه ورود " + price.format(s.entry) + " منتقل کنید."));

        c.addView(step("TP2  •  " + price.format(s.targets.get(1)), BLUE,
                "دوباره بخشی از پوزیشن را ببندید و سطح مرجع SL را به TP1 یعنی " + price.format(s.targets.get(0)) + " منتقل کنید."));
        c.addView(step("TP3  •  " + price.format(s.targets.get(2)), BLUE,
                "بخشی از پوزیشن را ببندید و سطح مرجع SL را به TP2 یعنی " + price.format(s.targets.get(1)) + " منتقل کنید."));
        c.addView(step("TP4  •  " + price.format(s.targets.get(3)), BLUE,
                "بخشی از پوزیشن را ببندید و سطح مرجع SL را به TP3 یعنی " + price.format(s.targets.get(2)) + " منتقل کنید."));
        c.addView(step("TP5  •  " + price.format(s.targets.get(4)), GOLD,
                "باقی‌مانده کوچک پوزیشن را تا TP5 نگه دارید تا بسته شود."));

        c.addView(step("قاعده SL در طول معامله", DANGER,
                "هر بار که سطح مرجع SL طبق مراحل بالا جابه‌جا می‌شود، معیار خروج همان بسته‌شدن کندل ۵ دقیقه‌ای آن طرف سطح فعلی SL است؛ صرفاً برخورد یا سایه، خروج محسوب نمی‌شود."));
        return c;
    }

    private String validateSignalLevels(Signal s) {
        if (s.entry <= 0 || s.stopLoss <= 0) {
            return "Entry و SL باید بزرگ‌تر از صفر باشند.";
        }

        if ("BUY".equals(s.position)) {
            if (s.stopLoss >= s.entry) {
                return "در سیگنال BUY، عدد SL باید پایین‌تر از Entry باشد. متن سیگنال را بررسی کنید.";
            }
            for (double tp : s.targets) {
                if (tp <= s.entry) {
                    return "در سیگنال BUY، تارگت‌ها باید بالاتر از Entry باشند. متن سیگنال را بررسی کنید.";
                }
            }
        } else if ("SELL".equals(s.position)) {
            if (s.stopLoss <= s.entry) {
                return "در سیگنال SELL، عدد SL باید بالاتر از Entry باشد. متن سیگنال را بررسی کنید.";
            }
            for (double tp : s.targets) {
                if (tp >= s.entry) {
                    return "در سیگنال SELL، تارگت‌ها باید پایین‌تر از Entry باشند. متن سیگنال را بررسی کنید.";
                }
            }
        }
        return null;
    }

    private TextView step(String heading, int color, String body) {
        TextView v = text(heading + "\n" + body, 14, TEXT, false);
        v.setLineSpacing(0, 1.25f);
        v.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable bg = round(SURFACE2, 14, color);
        bg.setStroke(dp(1), color);
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(7));
        v.setLayoutParams(lp);
        return v;
    }

    private TextView formula(String label, String value) {
        return kv(label, value, ACCENT);
    }

    private TextView kv(String label, String value, int valueColor) {
        TextView t = text(label + "    " + value, 15, TEXT, false);
        t.setPadding(dp(2), dp(8), dp(2), dp(8));
        if (valueColor != TEXT) {
            android.text.SpannableString sp = new android.text.SpannableString(t.getText());
            int start = label.length() + 4;
            sp.setSpan(new android.text.style.ForegroundColorSpan(valueColor), start, sp.length(), 0);
            sp.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), start, sp.length(), 0);
            t.setText(sp);
        }
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(round(SURFACE, 18, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(14));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(0, 0, 0, dp(12));
        return t;
    }

    private EditText edit(String hint, boolean numeric, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(round(SURFACE2, 13, LINE));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setMinLines(minLines);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != fill) g.setStroke(dp(1), stroke);
        return g;
    }

    private double number(String s) {
        try {
            String n = SignalParser.normalizeDigits(s).replace(",", "").trim();
            if (n.isEmpty()) return Double.NaN;
            return Double.parseDouble(n);
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
