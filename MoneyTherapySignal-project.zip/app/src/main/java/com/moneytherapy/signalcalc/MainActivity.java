package com.moneytherapy.signalcalc;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MODE_TEACHER = 0;
    private static final int MODE_BOT = 1;

    // The True Trade — Entry Market is a taker order. Official TTT docs list
    // taker fee = 0.04%, closing fee = 0%, funding fee = 0%.
    private static final double TTT_MARKET_ENTRY_FEE_PCT = 0.04;
    private static final double TTT_CLOSING_FEE_PCT = 0.0;

    private final int BG = Color.rgb(8, 12, 20);
    private final int SURFACE = Color.rgb(17, 23, 36);
    private final int SURFACE2 = Color.rgb(23, 31, 48);
    private final int SURFACE3 = Color.rgb(29, 39, 59);
    private final int TEXT = Color.rgb(244, 247, 252);
    private final int MUTED = Color.rgb(160, 171, 191);
    private final int ACCENT = Color.rgb(42, 220, 174);
    private final int BLUE = Color.rgb(76, 164, 255);
    private final int DANGER = Color.rgb(255, 94, 115);
    private final int GOLD = Color.rgb(246, 195, 81);
    private final int LINE = Color.rgb(43, 54, 77);

    private EditText signalInput;
    private EditText capitalInput;
    private EditText customMarginInput;
    private EditText customLeverageInput;
    private EditText customExitPriceInput;
    private EditText customExtraCostInput;
    private Button teacherTab;
    private Button botTab;
    private LinearLayout outputArea;
    private LinearLayout simulatorResultArea;

    private int currentMode = MODE_TEACHER;
    private Signal lastSignal;
    private double lastCapital = Double.NaN;

    private final DecimalFormat money = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat price = new DecimalFormat("#,##0.########", DecimalFormatSymbols.getInstance(Locale.US));
    private final DecimalFormat pct = new DecimalFormat("0.####", DecimalFormatSymbols.getInstance(Locale.US));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("MoneyTherapy", 26, TEXT, true);
        root.addView(title);
        TextView sub = text("سیگنال → مارجین، اهرم و سود تارگت‌ها", 13, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(14));
        root.addView(sub);

        // Compact mode tabs
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(round(SURFACE, 16, LINE));
        LinearLayout.LayoutParams tabWrap = new LinearLayout.LayoutParams(-1, dp(50));
        tabWrap.setMargins(0, 0, 0, dp(12));
        root.addView(tabs, tabWrap);

        teacherTab = tabButton("استاد");
        botTab = tabButton("ربات");
        tabs.addView(teacherTab, weighted());
        tabs.addView(botTab, weighted());
        styleTabs();

        LinearLayout inputCard = card(14);
        TextView inputTitle = sectionTitle("سیگنال و سرمایه");
        inputCard.addView(inputTitle);

        capitalInput = edit("سرمایه (USDT)", true, 1);
        capitalInput.setText("75");
        inputCard.addView(capitalInput, new LinearLayout.LayoutParams(-1, dp(50)));
        inputCard.addView(space(8));

        signalInput = edit("متن سیگنال را Paste کنید", false, 5);
        signalInput.setGravity(Gravity.TOP | Gravity.START);
        inputCard.addView(signalInput, new LinearLayout.LayoutParams(-1, dp(145)));
        root.addView(inputCard);

        Button calc = actionButton("محاسبه مستقیم از سیگنال", ACCENT, Color.rgb(4, 26, 21));
        LinearLayout.LayoutParams calcLp = new LinearLayout.LayoutParams(-1, dp(52));
        calcLp.setMargins(0, 0, 0, dp(14));
        root.addView(calc, calcLp);

        outputArea = new LinearLayout(this);
        outputArea.setOrientation(LinearLayout.VERTICAL);
        root.addView(outputArea);

        teacherTab.setOnClickListener(v -> switchMode(MODE_TEACHER));
        botTab.setOnClickListener(v -> switchMode(MODE_BOT));
        calc.setOnClickListener(v -> calculateDirect());

        setContentView(scroll);
    }

    private void switchMode(int mode) {
        currentMode = mode;
        styleTabs();
        if (lastSignal != null && !Double.isNaN(lastCapital)) {
            renderDirect(lastSignal, lastCapital);
        }
    }

    private void calculateDirect() {
        String raw = signalInput.getText().toString().trim();
        double capital = number(capitalInput.getText().toString());

        if (raw.isEmpty() || Double.isNaN(capital) || capital <= 0) {
            Toast.makeText(this, "متن سیگنال و سرمایه معتبر را وارد کنید.", Toast.LENGTH_SHORT).show();
            return;
        }

        Signal s = SignalParser.parse(raw);
        if (!s.isValid()) {
            Toast.makeText(this, "Name، Position، Entry، TP1 تا TP5 و حدضرر کامل تشخیص داده نشد.", Toast.LENGTH_LONG).show();
            return;
        }

        String err = validateSignalLevels(s);
        if (err != null) {
            Toast.makeText(this, err, Toast.LENGTH_LONG).show();
            return;
        }

        lastSignal = s;
        lastCapital = capital;
        renderDirect(s, capital);
    }

    private void renderDirect(Signal s, double capital) {
        outputArea.removeAllViews();
        double slPct = TradeMath.slDistancePercent(s);

        if (currentMode == MODE_TEACHER) {
            // صحبت اول استاد: ریسک 5 تا 10 درصد. برای خواسته کاربر جهت کم‌کردن ضرر، پایین بازه یعنی 5%.
            // تنها عدد مارجین صریح در مثال استاد 10 دلار بود؛ از آن فقط برای ساخت یک جفت مستقیم مارجین/اهرم استفاده می‌شود.
            double riskPct = 5.0;
            double riskDollar = TradeMath.riskDollars(capital, riskPct);
            double position = TradeMath.positionSize(riskDollar, slPct);
            double margin = 10.0;
            double leverage = TradeMath.leverage(position, margin);

            outputArea.addView(primaryResultCard(
                    "حالت استاد",
                    "ریسک ۵٪ (پایین‌ترین عدد بازه ۵ تا ۱۰٪) + مارجین ۱۰ دلاریِ مثال استاد",
                    margin,
                    leverage,
                    riskDollar,
                    riskPct,
                    position,
                    s,
                    false
            ));

            outputArea.addView(compactNote(
                    "در صحبت اول، استاد مارجین یا اهرم ثابت تعیین نکرده بود. عدد ۱۰ دلار فقط همان مارجینِ مثال استاد است و اهرم از روی حجم پوزیشن محاسبه می‌شود."
            ));
            prefillSimulator(margin, leverage);
        } else {
            // ربات برای 75 دلار: 0.30 دلار ریسک و 3x ایزوله. 0.30/75 = 0.4%؛ برای سرمایه دیگر همان نسبت نمایش داده می‌شود.
            double riskPct = 0.4;
            double riskDollar = capital * 0.004;
            double leverage = 3.0;
            double position = TradeMath.positionSize(riskDollar, slPct);
            double margin = TradeMath.margin(position, leverage);

            outputArea.addView(primaryResultCard(
                    "حالت ربات",
                    Math.abs(capital - 75.0) < 0.01
                            ? "ریسک ۰٫۳۰ دلار + اهرم ۳× ایزوله"
                            : "ریسک ۰٫۴٪ (نسبت همان مثال ۰٫۳۰ دلار از ۷۵ دلار) + اهرم ۳× ایزوله",
                    margin,
                    leverage,
                    riskDollar,
                    riskPct,
                    position,
                    s,
                    true
            ));
            prefillSimulator(margin, leverage);
        }

        outputArea.addView(targetsCard(s, currentDirectPosition(s, capital, slPct)));
        outputArea.addView(rulesCard(s));
        outputArea.addView(netCalculatorCard(s, capital, slPct));
    }

    private double currentDirectPosition(Signal s, double capital, double slPct) {
        if (currentMode == MODE_TEACHER) {
            return TradeMath.positionSize(capital * 0.05, slPct);
        }
        return TradeMath.positionSize(capital * 0.004, slPct);
    }

    private LinearLayout primaryResultCard(String modeTitle, String basis, double margin, double leverage,
                                           double riskDollar, double riskPct, double position, Signal s,
                                           boolean isolated) {
        LinearLayout c = card(16);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView h = text(modeTitle, 17, TEXT, true);
        TextView badge = badge(isolated ? "ISOLATED" : "فرمول استاد", isolated ? BLUE : GOLD);
        head.addView(h, weighted());
        head.addView(badge);
        c.addView(head);

        TextView basisText = text(basis, 12, MUTED, false);
        basisText.setPadding(0, dp(5), 0, dp(12));
        c.addView(basisText);

        LinearLayout row1 = metricRow();
        row1.addView(metric("مارجین", money.format(margin) + " USDT", ACCENT), weightedWithMargin(0, 4));
        row1.addView(metric("اهرم", pct.format(leverage) + "×" + (isolated ? " ایزوله" : ""), BLUE), weightedWithMargin(4, 0));
        c.addView(row1);

        LinearLayout row2 = metricRow();
        row2.addView(metric("ریسک تا عدد SL", money.format(riskDollar) + " USDT", DANGER), weightedWithMargin(0, 4));
        row2.addView(metric("درصد ریسک", pct.format(riskPct) + "%", GOLD), weightedWithMargin(4, 0));
        c.addView(row2);

        double tp1Full = TradeMath.profitAtTarget(s, s.targets.get(0), position);
        double tp1Booked = tp1Full * 0.5;
        LinearLayout row3 = metricRow();
        row3.addView(metric("حجم پوزیشن", money.format(position) + " USDT", TEXT), weightedWithMargin(0, 4));
        row3.addView(metric("سود برداشت TP1", "+" + money.format(tp1Booked) + " USDT", ACCENT), weightedWithMargin(4, 0));
        c.addView(row3);

        double slPct = TradeMath.slDistancePercent(s);
        TextView tiny = text("فاصله Entry تا SL: " + pct.format(slPct) + "%  •  Entry: " + price.format(s.entry) + "  •  SL: " + price.format(s.stopLoss), 11, MUTED, false);
        tiny.setPadding(0, dp(9), 0, 0);
        c.addView(tiny);
        return c;
    }

    private LinearLayout targetsCard(Signal s, double position) {
        LinearLayout c = card(14);
        c.addView(sectionTitle("سود تارگت‌ها"));

        for (int i = 0; i < 5; i++) {
            double target = s.targets.get(i);
            double fullProfit = TradeMath.profitAtTarget(s, target, position);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(7), 0, dp(7));

            TextView left = text("TP" + (i + 1) + "  " + price.format(target), 13, i == 0 ? ACCENT : TEXT, i == 0);
            String value = "+" + money.format(fullProfit) + " USDT";
            if (i == 0) value += "  |  برداشت ۵۰٪: +" + money.format(fullProfit * 0.5);
            TextView right = text(value, 12, i == 0 ? ACCENT : GOLD, true);
            right.setGravity(Gravity.END);
            row.addView(left, weighted());
            row.addView(right);
            c.addView(row);

            if (i < 4) c.addView(divider());
        }

        TextView hint = text("برای TP2 تا TP4 درصد خروج در صحبت استاد مشخص نشده؛ بنابراین فقط سودِ کل حجم در آن قیمت نمایش داده می‌شود.", 11, MUTED, false);
        hint.setPadding(0, dp(8), 0, 0);
        c.addView(hint);
        return c;
    }

    private LinearLayout netCalculatorCard(Signal s, double capital, double slPct) {
        LinearLayout c = card(14);
        c.addView(sectionTitle("ماشین‌حساب خالص شخصی"));
        TextView explain = text("مارجین و اهرم را وارد کن؛ کارمزد The True Trade برای Entry Market به‌صورت خودکار اعمال می‌شود و سود/زیان خالص بدون شمردن اصل مارجین نمایش داده می‌شود.", 12, MUTED, false);
        explain.setPadding(0, 0, 0, dp(10));
        c.addView(explain);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        customMarginInput = edit("مارجین (USDT)", true, 1);
        customLeverageInput = edit("اهرم", true, 1);
        row1.addView(customMarginInput, weightedWithMargin(0, 4));
        row1.addView(customLeverageInput, weightedWithMargin(4, 0));
        c.addView(row1);
        c.addView(space(8));

        LinearLayout feeBox = new LinearLayout(this);
        feeBox.setOrientation(LinearLayout.VERTICAL);
        feeBox.setPadding(dp(12), dp(9), dp(12), dp(9));
        feeBox.setBackground(round(SURFACE2, 12, LINE));
        feeBox.addView(kvCompact("کارمزد ورود Market (Taker)", "0.04% خودکار", GOLD));
        feeBox.addView(kvCompact("کارمزد بستن معامله", "0%", ACCENT));
        feeBox.addView(kvCompact("Funding", "0%", ACCENT));
        c.addView(feeBox);
        c.addView(space(8));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        customExitPriceInput = edit("قیمت خروج واقعی (اختیاری)", true, 1);
        customExtraCostInput = edit("شبکه/هزینه دیگر USDT (اختیاری)", true, 1);
        row3.addView(customExitPriceInput, weightedWithMargin(0, 4));
        row3.addView(customExtraCostInput, weightedWithMargin(4, 0));
        c.addView(row3);

        double directPosition = currentDirectPosition(s, capital, slPct);
        double defaultMargin;
        double defaultLeverage;
        if (currentMode == MODE_TEACHER) {
            defaultMargin = 10.0;
            defaultLeverage = TradeMath.leverage(directPosition, defaultMargin);
        } else {
            defaultLeverage = 3.0;
            defaultMargin = TradeMath.margin(directPosition, defaultLeverage);
        }
        customMarginInput.setText(moneyPlain(defaultMargin));
        customLeverageInput.setText(pct.format(defaultLeverage));
        TextView feeHint = text("برای سیگنال‌های Entry Market، برنامه ۰٫۰۴٪ کارمزد Taker را روی ارزش پوزیشن هنگام ورود لحاظ می‌کند. طبق مستندات TTT، Closing Fee و Funding صفر هستند. هزینه شبکه/اسلیپیج فقط اگر واقعاً رخ دهد از قبل عدد ثابتی ندارد؛ می‌توانی هزینه واقعی را در کادر اختیاری وارد کنی.", 10, MUTED, false);
        feeHint.setPadding(0, dp(7), 0, 0);
        c.addView(feeHint);

        Button simulate = actionButton("محاسبه سود و زیان خالص", SURFACE3, TEXT);
        LinearLayout.LayoutParams simLp = new LinearLayout.LayoutParams(-1, dp(46));
        simLp.setMargins(0, dp(9), 0, dp(9));
        c.addView(simulate, simLp);

        simulatorResultArea = new LinearLayout(this);
        simulatorResultArea.setOrientation(LinearLayout.VERTICAL);
        c.addView(simulatorResultArea);

        simulate.setOnClickListener(v -> renderNetCalculatorResult(s, capital));
        return c;
    }

    private void renderNetCalculatorResult(Signal s, double capital) {
        double margin = number(customMarginInput.getText().toString());
        double leverage = number(customLeverageInput.getText().toString());
        double entryFeePct = TTT_MARKET_ENTRY_FEE_PCT;
        double exitFeePct = TTT_CLOSING_FEE_PCT;
        double actualExit = number(customExitPriceInput.getText().toString());
        double extraCosts = number(customExtraCostInput.getText().toString());
        if (Double.isNaN(extraCosts)) extraCosts = 0.0;

        if (Double.isNaN(margin) || margin <= 0 || Double.isNaN(leverage) || leverage <= 0) {
            Toast.makeText(this, "مارجین و اهرم معتبر وارد کنید.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (extraCosts < 0) {
            Toast.makeText(this, "هزینه‌های دیگر نمی‌تواند منفی باشد.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Double.isNaN(actualExit) && actualExit <= 0) {
            Toast.makeText(this, "قیمت خروج واقعی معتبر نیست.", Toast.LENGTH_SHORT).show();
            return;
        }

        double position = TradeMath.positionFromMarginLeverage(margin, leverage);
        double qty = TradeMath.baseQuantity(s, position);
        double entryFee = TradeMath.fee(position, entryFeePct);

        simulatorResultArea.removeAllViews();
        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(12), dp(10), dp(12), dp(10));
        summary.setBackground(round(SURFACE2, 13, LINE));

        summary.addView(kvCompact("حجم پوزیشن", money.format(position) + " USDT", TEXT));
        summary.addView(kvCompact("کارمزد ورود TTT (0.04%)", money.format(entryFee) + " USDT", MUTED));
        summary.addView(kvCompact("کارمزد خروج / Funding", "0.00 USDT", ACCENT));

        for (int i = 0; i < 5; i++) {
            double target = s.targets.get(i);
            double net = TradeMath.netPnlAtExit(s, target, position, entryFeePct, exitFeePct, extraCosts);
            String value = signedMoney(net) + " USDT";
            summary.addView(kvCompact("TP" + (i + 1) + " سود خالص کل حجم", value, net >= 0 ? ACCENT : DANGER));

            if (i == 0) {
                double halfNet = TradeMath.netPnlAtExit(s, target, position * 0.5, entryFeePct, exitFeePct, extraCosts * 0.5);
                summary.addView(kvCompact("TP1 برداشت ۵۰٪ طبق استاد", signedMoney(halfNet) + " USDT", halfNet >= 0 ? ACCENT : DANGER));
            }
        }

        double slNet = TradeMath.netPnlAtExit(s, s.stopLoss, position, entryFeePct, exitFeePct, extraCosts);
        double slLoss = Math.max(0.0, -slNet);
        double slLossPct = capital > 0 ? slLoss / capital * 100.0 : Double.NaN;
        summary.addView(divider());
        summary.addView(kvCompact("ضرر برآوردی اگر دقیقاً روی SL بسته شود", money.format(slLoss) + " USDT  (" + pct.format(slLossPct) + "%)", DANGER));

        double exitNotionalAtSl = TradeMath.notionalAtPrice(s, s.stopLoss, position);
        double exitFeeAtSl = TradeMath.fee(exitNotionalAtSl, exitFeePct);
        summary.addView(kvCompact("کل هزینه در سناریوی SL", money.format(entryFee + exitFeeAtSl + extraCosts) + " USDT", MUTED));

        if (!Double.isNaN(actualExit)) {
            double actualNet = TradeMath.netPnlAtExit(s, actualExit, position, entryFeePct, exitFeePct, extraCosts);
            if (actualNet < 0) {
                double actualLoss = -actualNet;
                double actualLossPct = capital > 0 ? actualLoss / capital * 100.0 : Double.NaN;
                summary.addView(kvCompact("ضرر واقعی با قیمت خروج " + price.format(actualExit), money.format(actualLoss) + " USDT  (" + pct.format(actualLossPct) + "%)", DANGER));
            } else {
                summary.addView(kvCompact("نتیجه واقعی با قیمت خروج " + price.format(actualExit), "+" + money.format(actualNet) + " USDT", ACCENT));
            }
        }

        TextView warn = text("طبق روش استاد، لمس یا شادو به SL خروج نیست. عددِ SL فقط برآورد است؛ ضرر واقعی بعد از بسته‌شدن کندل ۵ دقیقه‌ای آن‌طرف SL و خروج دستی مشخص می‌شود. اصل مارجین سود محسوب نشده. کارمزد ثابت TTT خودکار لحاظ شده؛ قیمت خروج واقعی می‌تواند اثر اسلیپیج را هم وارد محاسبه کند و هزینه شبکه/سایر فقط در صورت وقوع از کادر اختیاری کم می‌شود.", 10, MUTED, false);
        warn.setPadding(0, dp(9), 0, 0);
        summary.addView(warn);
        simulatorResultArea.addView(summary);
    }

    private LinearLayout rulesCard(Signal s) {
        LinearLayout c = card(12);
        c.addView(sectionTitle("قواعد اجرای استاد"));
        String side = "BUY".equals(s.position) ? "زیر" : "بالای";
        c.addView(ruleLine("SL", "برخورد یا شادو خروج نیست؛ فقط بسته‌شدن کندل ۵ دقیقه‌ای " + side + " SL → خروج دستی.", DANGER));
        c.addView(ruleLine("TP1", "۵۰٪ پوزیشن بسته شود و سطح SL باقی‌مانده به Entry منتقل شود.", ACCENT));
        c.addView(ruleLine("TP2–TP4", "بخشی بسته شود و سطح SL به تارگت قبلی منتقل شود.", BLUE));
        c.addView(ruleLine("TP5", "باقی‌مانده کوچک تا TP5 نگه داشته شود.", GOLD));
        return c;
    }

    private TextView compactNote(String body) {
        TextView v = text(body, 11, MUTED, false);
        v.setPadding(dp(12), dp(10), dp(12), dp(10));
        v.setBackground(round(SURFACE, 12, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        v.setLayoutParams(lp);
        return v;
    }

    private void prefillSimulator(double margin, double leverage) {
        // Fields are created later in the current render pass; simulatorCard sets the same defaults.
    }

    private String validateSignalLevels(Signal s) {
        if (s.entry <= 0 || s.stopLoss <= 0) return "Entry و SL باید بزرگ‌تر از صفر باشند.";
        if ("BUY".equals(s.position)) {
            if (s.stopLoss >= s.entry) return "در BUY، SL باید پایین‌تر از Entry باشد.";
            for (double tp : s.targets) if (tp <= s.entry) return "در BUY، همه TPها باید بالاتر از Entry باشند.";
        } else if ("SELL".equals(s.position)) {
            if (s.stopLoss <= s.entry) return "در SELL، SL باید بالاتر از Entry باشد.";
            for (double tp : s.targets) if (tp >= s.entry) return "در SELL، همه TPها باید پایین‌تر از Entry باشند.";
        }
        return null;
    }

    private void styleTabs() {
        boolean teacher = currentMode == MODE_TEACHER;
        styleTab(teacherTab, teacher);
        styleTab(botTab, !teacher);
    }

    private void styleTab(Button b, boolean selected) {
        b.setTextColor(selected ? Color.rgb(4, 24, 20) : MUTED);
        b.setBackground(round(selected ? ACCENT : Color.TRANSPARENT, 12, selected ? ACCENT : Color.TRANSPARENT));
    }

    private Button tabButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private Button actionButton(String label, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(textColor);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(fill, 14, fill));
        return b;
    }

    private LinearLayout metricRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout metric(String label, String value, int valueColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackground(round(SURFACE2, 13, LINE));
        TextView l = text(label, 11, MUTED, false);
        TextView v = text(value, 16, valueColor, true);
        v.setPadding(0, dp(3), 0, 0);
        box.addView(l);
        box.addView(v);
        return box;
    }

    private TextView badge(String s, int color) {
        TextView t = text(s, 10, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(9), dp(5), dp(9), dp(5));
        t.setBackground(round(SURFACE2, 30, color));
        return t;
    }

    private LinearLayout ruleLine(String label, String body, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView chip = badge(label, color);
        TextView txt = text(body, 12, TEXT, false);
        txt.setPadding(dp(10), 0, 0, 0);
        row.addView(chip);
        row.addView(txt, weighted());
        return row;
    }

    private TextView kvCompact(String label, String value, int valueColor) {
        TextView t = text(label + "    " + value, 12, TEXT, false);
        t.setPadding(0, dp(4), 0, dp(4));
        android.text.SpannableString sp = new android.text.SpannableString(t.getText());
        int start = label.length() + 4;
        if (start < sp.length()) {
            sp.setSpan(new android.text.style.ForegroundColorSpan(valueColor), start, sp.length(), 0);
            sp.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), start, sp.length(), 0);
        }
        t.setText(sp);
        return t;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    private LinearLayout card(int padding) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(padding), dp(padding), dp(padding), dp(padding));
        c.setBackground(round(SURFACE, 18, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 16, TEXT, true);
        t.setPadding(0, 0, 0, dp(10));
        return t;
    }

    private EditText edit(String hint, boolean numeric, int minLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(round(SURFACE2, 12, LINE));
        e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setMinLines(minLines);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != fill && stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, -1, 1f);
    }

    private LinearLayout.LayoutParams weightedWithMargin(int startDp, int endDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(startDp), 0, dp(endDp), 0);
        return lp;
    }

    private double number(String s) {
        try {
            String n = SignalParser.normalizeDigits(s).replace(",", "").trim();
            if (n.isEmpty()) return Double.NaN;
            return Double.parseDouble(n);
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    private String signedMoney(double v) {
        if (Double.isNaN(v)) return "—";
        return (v >= 0 ? "+" : "-") + money.format(Math.abs(v));
    }

    private String moneyPlain(double v) {
        return new DecimalFormat("0.####", DecimalFormatSymbols.getInstance(Locale.US)).format(v);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
