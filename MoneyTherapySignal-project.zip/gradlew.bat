@echo off
set DIR=%~dp0
if not exist "%DIR%gradle\wrapper\gradle-wrapper.jar" (
  echo This phone-ready package bootstraps the wrapper on Android/Linux.
  echo On Windows, generate the standard Gradle wrapper first.
  exit /b 1
)
java -Dfile.encoding=UTF-8 -classpath "%DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
