
package com.moneytherapy.calculator

data class Signal(
    val symbol:String,
    val side:String,
    val entry:Double,
    val stopLoss:Double,
    val stopPercent:Double,
    val targets:List<Double>
)
