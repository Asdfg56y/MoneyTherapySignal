
package com.moneytherapy.calculator

data class Result(
    val price:Double,
    val gross:Double,
    val fee:Double,
    val net:Double
)

object PnlEngine {

    fun calculate(
        entry:Double,
        targets:List<Double>,
        positionSize:Double,
        feeRate:Double,
        short:Boolean
    ):List<Result>{

        return targets.map { price ->

            val move =
                if(short)
                    (entry-price)/entry
                else
                    (price-entry)/entry

            val gross = move * positionSize
            val fee = positionSize * feeRate

            Result(price,gross,fee,gross-fee)
        }
    }
}
