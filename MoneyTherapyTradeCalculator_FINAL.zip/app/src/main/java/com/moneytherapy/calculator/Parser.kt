
package com.moneytherapy.calculator

object Parser {

    fun parse(text:String):Map<String,String>{
        val result = mutableMapOf<String,String>()

        text.lines().forEach { line ->
            val p=line.split(":")
            if(p.size>1){
                result[p[0].trim()] = p.drop(1).joinToString(":").trim()
            }
        }

        return result
    }
}
