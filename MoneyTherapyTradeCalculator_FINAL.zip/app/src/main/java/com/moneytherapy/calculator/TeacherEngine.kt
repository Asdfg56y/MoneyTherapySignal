
package com.moneytherapy.calculator

data class TradePlan(
    val margin:Double,
    val leverage:Double,
    val positionSize:Double
)

object TeacherEngine {

    fun calculate(
        risk:Double,
        stopPercent:Double,
        maxLeverage:Double
    ):TradePlan {

        val rawLeverage = 100.0 / stopPercent
        val leverage = minOf(rawLeverage, maxLeverage)

        return TradePlan(
            margin = risk,
            leverage = leverage,
            positionSize = risk * leverage
        )
    }
}
