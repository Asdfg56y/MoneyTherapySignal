
MoneyTherapyTradeCalculator FINAL

Purpose:
Android project foundation for automating Moneytherapy signal calculations.

Implemented logic:
- Signal parser structure
- Teacher strategy engine
- Margin calculation
- Leverage calculation
- TP1-TP5 PnL simulation
- Stop loss loss calculation
- Fee configuration
- The True Trade settings
- GitHub Actions APK build workflow

Next step in Android Studio:
Add Gradle wrapper / Android SDK files and build APK.
